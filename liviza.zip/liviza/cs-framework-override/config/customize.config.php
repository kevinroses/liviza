<?php if ( ! defined( 'ABSPATH' ) ) { die; } // Cannot access pages directly.
// Customizer options - Coming soon with Liviza theme
$options            = array();
CSFramework_Customize::instance( $options );
