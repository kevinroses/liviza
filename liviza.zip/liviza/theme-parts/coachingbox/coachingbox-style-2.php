<article class="themestek-box themestek-box-coaching themestek-coachingbox-style-2">
	<div class="themestek-post-item"> 
		<div class="themestek-box-content">
			<div class="themestek-box-content-inner">

				<div class="ts-ihbox-icon">
					<?php themestek_coaching_icon(); ?>
				</div>
				<div class="themestek-des">
					<div class="themestek-pf-box-title"> 
						<h3><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
					</div>			 
				</div> 
				<a href="<?php echo get_permalink(); ?>" class="ts-coaching-link" tabindex="0"></a>	

            </div>
		</div>
	</div>
</article>
