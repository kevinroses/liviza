<?php if( themestek_header_slider_show() ) : ?>
	<div class="themestek-slider-wrapper">
		<?php echo themestek_header_slider(); ?>
	</div>
<?php endif;  // themestek_titlebar_show() ?>
